﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class sales
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(sales))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dailyRadioButton = New System.Windows.Forms.RadioButton()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.comboBoxMonth = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.comboBoxYear = New System.Windows.Forms.ComboBox()
        Me.yearRadioButton = New System.Windows.Forms.RadioButton()
        Me.monthRadioButton = New System.Windows.Forms.RadioButton()
        Me.loadBtn = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Location = New System.Drawing.Point(-3, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(357, 52)
        Me.Panel1.TabIndex = 41
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Monotype Corsiva", 26.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(80, 3)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(184, 43)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "Sales Report"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.DateTimePicker1)
        Me.GroupBox1.Controls.Add(Me.PictureBox1)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.dailyRadioButton)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.comboBoxMonth)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.comboBoxYear)
        Me.GroupBox1.Controls.Add(Me.yearRadioButton)
        Me.GroupBox1.Controls.Add(Me.monthRadioButton)
        Me.GroupBox1.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(16, 60)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(320, 200)
        Me.GroupBox1.TabIndex = 42
        Me.GroupBox1.TabStop = False
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.CustomFormat = "MM/dd/yyyy"
        Me.DateTimePicker1.Enabled = False
        Me.DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DateTimePicker1.Location = New System.Drawing.Point(137, 88)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(120, 27)
        Me.DateTimePicker1.TabIndex = 47
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(278, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(42, 37)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 46
        Me.PictureBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 97)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(116, 18)
        Me.Label1.TabIndex = 43
        Me.Label1.Text = "Select Date :"
        '
        'dailyRadioButton
        '
        Me.dailyRadioButton.AutoSize = True
        Me.dailyRadioButton.Location = New System.Drawing.Point(14, 42)
        Me.dailyRadioButton.Name = "dailyRadioButton"
        Me.dailyRadioButton.Size = New System.Drawing.Size(67, 22)
        Me.dailyRadioButton.TabIndex = 42
        Me.dailyRadioButton.TabStop = True
        Me.dailyRadioButton.Text = "Daily"
        Me.dailyRadioButton.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(7, 133)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(71, 18)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Month :"
        '
        'comboBoxMonth
        '
        Me.comboBoxMonth.Enabled = False
        Me.comboBoxMonth.FormattingEnabled = True
        Me.comboBoxMonth.Items.AddRange(New Object() {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"})
        Me.comboBoxMonth.Location = New System.Drawing.Point(137, 125)
        Me.comboBoxMonth.Name = "comboBoxMonth"
        Me.comboBoxMonth.Size = New System.Drawing.Size(120, 26)
        Me.comboBoxMonth.TabIndex = 2
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(7, 168)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(57, 18)
        Me.Label5.TabIndex = 3
        Me.Label5.Text = "Year :"
        '
        'comboBoxYear
        '
        Me.comboBoxYear.Enabled = False
        Me.comboBoxYear.FormattingEnabled = True
        Me.comboBoxYear.Items.AddRange(New Object() {"2017", "2018", "2019", "2021", "2022", "2023", "2024", "2025", "2026", "2027", "2028", "2029"})
        Me.comboBoxYear.Location = New System.Drawing.Point(137, 157)
        Me.comboBoxYear.Name = "comboBoxYear"
        Me.comboBoxYear.Size = New System.Drawing.Size(120, 26)
        Me.comboBoxYear.TabIndex = 4
        '
        'yearRadioButton
        '
        Me.yearRadioButton.AutoSize = True
        Me.yearRadioButton.Location = New System.Drawing.Point(191, 42)
        Me.yearRadioButton.Name = "yearRadioButton"
        Me.yearRadioButton.Size = New System.Drawing.Size(76, 22)
        Me.yearRadioButton.TabIndex = 41
        Me.yearRadioButton.TabStop = True
        Me.yearRadioButton.Text = "Yearly"
        Me.yearRadioButton.UseVisualStyleBackColor = True
        '
        'monthRadioButton
        '
        Me.monthRadioButton.AutoSize = True
        Me.monthRadioButton.Location = New System.Drawing.Point(90, 42)
        Me.monthRadioButton.Name = "monthRadioButton"
        Me.monthRadioButton.Size = New System.Drawing.Size(90, 22)
        Me.monthRadioButton.TabIndex = 40
        Me.monthRadioButton.TabStop = True
        Me.monthRadioButton.Text = "Monthly"
        Me.monthRadioButton.UseVisualStyleBackColor = True
        '
        'loadBtn
        '
        Me.loadBtn.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.loadBtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.loadBtn.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.loadBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.loadBtn.Location = New System.Drawing.Point(117, 287)
        Me.loadBtn.Name = "loadBtn"
        Me.loadBtn.Size = New System.Drawing.Size(100, 30)
        Me.loadBtn.TabIndex = 44
        Me.loadBtn.Text = "&Load"
        Me.loadBtn.UseVisualStyleBackColor = False
        '
        'sales
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Silver
        Me.ClientSize = New System.Drawing.Size(349, 347)
        Me.Controls.Add(Me.loadBtn)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "sales"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "sales"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents dailyRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents comboBoxMonth As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents comboBoxYear As System.Windows.Forms.ComboBox
    Friend WithEvents yearRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents monthRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents loadBtn As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
End Class
