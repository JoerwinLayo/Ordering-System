﻿Imports Microsoft.Office.Interop

Public Class salesform


    Private Sub ToolStripLabel1_Click(sender As Object, e As EventArgs) Handles ToolStripLabel1.Click
        Me.Close()
    End Sub



    Private Sub ToolStripLabel2_Click(sender As Object, e As EventArgs) Handles ToolStripLabel2.Click
            export()
    End Sub
    Sub export()

        Dim ex_app As Excel.Application
        Dim ex_book As Excel.Workbook
        Dim ex_sheet As Excel.Worksheet

        Dim value1 As String = sales.DateTimePicker1.Text
        Dim value2 As String = value1.Replace("/", "-")

        Dim location = "C:\Users\bubbles123\Documents\Visual Studio 2013\Projects\Ordering System\SalesandReciepts\Sales Report" + DateTime.Now.ToString("dd MMM yyyy hh mm ss") & value2 & ".xlsx"
        Try
            ex_app = CreateObject("Excel.Application")
            ex_book = ex_app.Workbooks.Add
            ex_sheet = ex_book.ActiveSheet

            ex_sheet.Cells(1, 4).Value = titleLabel.Text
            ex_sheet.Cells(1, 4).HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter
            ex_sheet.Cells(2, 4).Value = Label1.Text + " " + salesLabel.Text

            ex_sheet.Cells(4, 1).Value = "Invoice ID"
            ex_sheet.Cells(4, 2).Value = "Total"
            ex_sheet.Cells(4, 3).Value = "Cash"
            ex_sheet.Cells(4, 4).Value = "Date Purchase"
            ex_sheet.Cells(4, 5).Value = "Time Purchase"
            ex_sheet.Cells(4, 6).Value = "Food Name"
            ex_sheet.Cells(4, 7).Value = "Staff Name"
            With ex_sheet.Range("A4", "N4")
                .Font.Bold = True
                .HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter
                .ColumnWidth = 20
            End With

            Dim row As Integer = 5
            Dim col As Integer = 1

            For Each item As ListViewItem In ListView1.Items
                For i As Integer = 0 To item.SubItems.Count - 1
                    ex_sheet.Cells(row, col).Value = item.SubItems(i).Text
                    col = col + 1
                Next
                ex_sheet.Range("A" & row & "", "N" & row & "").HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter
                row += 1
                col = 1
            Next

            If (System.IO.File.Exists(location)) Then
                System.IO.File.Delete(location)
                ex_sheet.SaveAs(location)
                MessageBox.Show("You File Name is " + location, "File Name", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                ex_sheet.SaveAs(location)
                MessageBox.Show("You File Name is " + location, "File Name", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

            
            ex_book.Close()
            ex_app.Quit()

            ex_app = Nothing
            ex_book = Nothing
            ex_sheet = Nothing
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Filterbtn_Click(sender As Object, e As EventArgs) Handles Filterbtn.Click
        If Filterbtn.Enabled = True Then
            ToolStripLabel2.Enabled = True
            sales.Show()
        End If
    End Sub
End Class