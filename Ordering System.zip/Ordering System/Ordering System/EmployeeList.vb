﻿Imports MySql.Data.MySqlClient
Imports System.IO
Public Class EmployeeList
    Dim imageLocation As String = ""
    Private Sub closeBtn_Click(sender As Object, e As EventArgs) Handles closeBtn.Click
        Me.Close()
    End Sub
    Private Sub ListView1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListView1.SelectedIndexChanged
        Dim index = ListView1.FocusedItem.Index
        idTextBox.Text = ListView1.Items(index).Text
        showinfo(idTextBox.Text)
    End Sub
    Sub showinfo(ByVal id As String)
        connect()
        Try
            Dim query As String = "SELECT * FROM staff,position,login_user where staff.p_id = position.p_id and login_user.staff_id = staff.staff_id and login_user.pincode and staff.staff_id = @id "
            Dim comm = New MySqlCommand(query, conn)
            comm.Parameters.AddWithValue("@id", id)
            Dim dr = comm.ExecuteReader
            While dr.Read
                idTextBox.Text = dr("staff_id").ToString
                nameTextBox.Text = dr("f_name").ToString
                agetxt.Text = dr("age").ToString
                emailTextBox.Text = dr("email").ToString
                addresstxt.Text = dr("address").ToString
                contactTextBox.Text = dr("contact").ToString
                genderComboBox.Text = dr("gender").ToString
                positionComboBox.Text = dr("position").ToString
                statcombo.Text = dr("status").ToString
                pincode.Text = dr("pincode").ToString

                Dim images() As Byte = dr("image")
                If images.Equals(Nothing) Then
                    PictureBox1.Image = Nothing
                Else
                    Dim ms As New MemoryStream(images)
                    PictureBox1.Image = Image.FromStream(ms)
                End If
            End While
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        conn.Close()
    End Sub

    Private Sub EmployeeList_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        retrieves()
        autogenerate()
        loadData()
    End Sub
    Sub retrieves()
        connect()
        Dim dr As MySqlDataReader
        ListView1.Items.Clear()
        Try
            Dim query As String = "SELECT * FROM staff,position,login_user where staff.p_id = position.p_id and login_user.staff_id = staff.staff_id and login_user.pincode "
            Dim com As New MySqlCommand(query, conn)
            dr = com.ExecuteReader
            While dr.Read
                With ListView1.Items.Add(dr("staff_id").ToString)
                    .SubItems.Add(dr("f_name").ToString)
                    .SubItems.Add(dr("age").ToString)
                    .SubItems.Add(dr("email").ToString)
                    .SubItems.Add(dr("Address").ToString)
                    .SubItems.Add(dr("contact").ToString)
                    .SubItems.Add(dr("gender").ToString)
                    .SubItems.Add(dr("position").ToString)
                    .SubItems.Add(dr("status").ToString)
                    .SubItems.Add(dr("pincode").ToString)
                End With
            End While
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Sub loadData()
        connect()
        Try
            Dim query As String = "select * from view_position"
            cmd = New MySqlCommand(query, conn)
            Dim dr = cmd.ExecuteReader
            While dr.Read
                positionComboBox.Items.Add(dr("position").ToString)
            End While
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
        conn.Close()
    End Sub
    Private Sub deleteBtn_Click(sender As Object, e As EventArgs) Handles deleteBtn.Click
        If nameTextBox.Text = "" And agetxt.Text = "" And emailTextBox.Text = "" And addresstxt.Text = "" And contactTextBox.Text = "" And genderComboBox.Text = "" And positionComboBox.Text = "" And statcombo.Text = "" And pincode.Text = "" Then
            MessageBox.Show("Choose before you delete!", "Textfields Empty", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            Dim connection As New MySqlConnection("server=localhost;user id=root;database=ordering_softeng")
            Dim params(0) As MySqlParameter
            params(0) = New MySqlParameter("ID", MySqlDbType.Int32)
            params(0).Value = idTextBox.Text
            Dim cmd As New MySqlCommand()
            cmd.Connection = connection
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "delete_staff"
            cmd.Parameters.AddRange(params)
            connection.Open()
            cmd.ExecuteNonQuery()
            MessageBox.Show("Data Successfully Deleted!", "Delete Successful", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            retrieves()
            autogenerate()
            clear()
            connection.Close()
        End If
    End Sub
    
    Sub autogenerate()
        connect()
        Try
            Dim sql As String = "SELECT * from view_staff_generate"
            Dim cm As New MySqlCommand(sql, conn)
            Dim numbers As Integer

            If IsDBNull(cm.ExecuteScalar) Then
                numbers = 1
                idTextBox.Text = numbers
            Else
                numbers = cm.ExecuteScalar + 1
                idTextBox.Text = numbers
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        conn.Close()
    End Sub
    Sub clear()
        nameTextBox.Text = ""
        emailTextBox.Text = ""
        contactTextBox.Text = ""
        genderComboBox.Text = ""
        positionComboBox.Text = ""
        pincode.Text = ""
        addresstxt.Text = ""
        statcombo.Text = ""
        agetxt.Text = ""
        searchtxt.Text = ""
        PictureBox1.Image = Nothing
    End Sub
    Sub updateusers()
        If nameTextBox.Text = "" And agetxt.Text = "" And emailTextBox.Text = "" And addresstxt.Text = "" And contactTextBox.Text = "" And genderComboBox.Text = "" And positionComboBox.Text = "" And statcombo.Text = "" And pincode.Text = "" Then
            MessageBox.Show("Please choose to update!", "Textfields Empty", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            If (contactTextBox.Text.Length() < 11) Then
                MessageBox.Show("The Contact Number should have 11 digits!", "Invalid Entry", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Else
                If (pincode.Text.Length() < 8) Then
                    MessageBox.Show("The Pincode should have 8 digits!", "Invalid Entry", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Else
                    Dim connection As New MySqlConnection("server=localhost;user id=root;database=ordering_softeng")
                    Dim params(1) As MySqlParameter
                    params(0) = New MySqlParameter("ID", MySqlDbType.Int32)
                    params(0).Value = idTextBox.Text
                    params(1) = New MySqlParameter("PIN", MySqlDbType.VarChar)
                    params(1).Value = pincode.Text
                    Dim cmd As New MySqlCommand()
                    cmd.Connection = connection
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.CommandText = "update_users"
                    cmd.Parameters.AddRange(params)
                    connection.Open()
                    cmd.ExecuteNonQuery()
                    retrieves()
                    autogenerate()
                    clear()
                    connection.Close()
                End If
            End If
        End If
    End Sub
    Sub updatestaff()
        If nameTextBox.Text = "" And agetxt.Text = "" And emailTextBox.Text = "" And addresstxt.Text = "" And contactTextBox.Text = "" And genderComboBox.Text = "" And positionComboBox.Text = "" And statcombo.Text = "" And pincode.Text = "" Then
            MessageBox.Show("Please choose  to update!", "Textfields Empty", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            If (contactTextBox.Text.Length() < 11) Then
                MessageBox.Show("The Contact Number should have 11 digits!", "Invalid Entry", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Else
                If (pincode.Text.Length() < 8) Then
                    MessageBox.Show("The Pincode should have 8 digits!", "Invalid Entry", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Else
                    Dim connection As New MySqlConnection("server=localhost;user id=root;database=ordering_softeng")
                    Dim mstream As New MemoryStream()
                    PictureBox1.Image.Save(mstream, System.Drawing.Imaging.ImageFormat.Jpeg)
                    Dim images() As Byte = mstream.GetBuffer()
                    mstream.Close()

                    Dim parameters(9) As MySqlParameter

                    parameters(0) = New MySqlParameter("ID", MySqlDbType.VarChar)
                    parameters(0).Value = idTextBox.Text


                    parameters(1) = New MySqlParameter("NAME", MySqlDbType.VarChar)
                    parameters(1).Value = nameTextBox.Text

                    parameters(2) = New MySqlParameter("AGE", MySqlDbType.VarChar)
                    parameters(2).Value = agetxt.Text

                    parameters(3) = New MySqlParameter("EMAIL", MySqlDbType.VarChar)
                    parameters(3).Value = emailTextBox.Text

                    parameters(4) = New MySqlParameter("ADDR", MySqlDbType.VarChar)
                    parameters(4).Value = addresstxt.Text

                    parameters(5) = New MySqlParameter("CON", MySqlDbType.VarChar)
                    parameters(5).Value = contactTextBox.Text

                    parameters(6) = New MySqlParameter("GEN", MySqlDbType.VarChar)
                    parameters(6).Value = genderComboBox.Text

                    parameters(7) = New MySqlParameter("PID", MySqlDbType.VarChar)
                    parameters(7).Value = positionComboBox.Text

                    parameters(8) = New MySqlParameter("STAT", MySqlDbType.VarChar)
                    parameters(8).Value = statcombo.Text

                    parameters(9) = New MySqlParameter("IMAGE", MySqlDbType.Blob)
                    parameters(9).Value = images

                    Dim cmd As New MySqlCommand()
                    cmd.Connection = connection
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.CommandText = "update_staff"
                    cmd.Parameters.AddRange(parameters)
                    connection.Open()
                    cmd.ExecuteNonQuery()
                    MessageBox.Show("Data Successfully UPDATED!")
                    updateusers()
                    retrieves()
                    autogenerate()
                    clear()
                    connection.Close()
                End If
            End If
        End If
    End Sub
    Private Sub updateBtn_Click(sender As Object, e As EventArgs) Handles updateBtn.Click
        updatestaff()
    End Sub

    Private Sub addBtn_Click(sender As Object, e As EventArgs) Handles addBtn.Click
        insertstaff()
    End Sub
    Sub insertuser()
        If nameTextBox.Text = "" And agetxt.Text = "" And emailTextBox.Text = "" And addresstxt.Text = "" And contactTextBox.Text = "" And genderComboBox.Text = "" And positionComboBox.Text = "" And statcombo.Text = "" And pincode.Text = "" Then
            MessageBox.Show("Please Fill up the blank to insert!", "Textfields Empty", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            If (contactTextBox.Text.Length() < 11) Then
                MessageBox.Show("The Contact Number should have 11 digits!", "Invalid Entry", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Else
                If (pincode.Text.Length() < 8) Then
                    MessageBox.Show("The Pincode should have 8 digits!", "Invalid Entry", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Else
                    Dim connection As New MySqlConnection("server=localhost;user id=root;database=ordering_softeng")

                    Dim parameters(1) As MySqlParameter

                    parameters(0) = New MySqlParameter("ID", MySqlDbType.VarChar)
                    parameters(0).Value = nameTextBox.Text

                    parameters(1) = New MySqlParameter("PIN", MySqlDbType.VarChar)
                    parameters(1).Value = pincode.Text


                    Dim cmd As New MySqlCommand()
                    cmd.Connection = connection
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.CommandText = "insert_users"
                    cmd.Parameters.AddRange(parameters)
                    connection.Open()
                    If cmd.ExecuteNonQuery() = 1 Then
                        retrieves()
                        autogenerate()
                        clear()
                    Else
                        MessageBox.Show("Not inserted")
                    End If
                    connection.Close()
                End If
            End If
        End If
    End Sub
    Sub insertstaff()
        If nameTextBox.Text = "" And agetxt.Text = "" And emailTextBox.Text = "" And addresstxt.Text = "" And contactTextBox.Text = "" And genderComboBox.Text = "" And positionComboBox.Text = "" And statcombo.Text = "" And pincode.Text = "" Then
            MessageBox.Show("Please Fill up the blank to insert!", "Textfields Empty", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            If (contactTextBox.Text.Length() < 11) Then
                MessageBox.Show("The Contact Number should have 11 digits!", "Invalid Entry", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Else
                If (pincode.Text.Length() < 8) Then
                    MessageBox.Show("The Pincode should have 8 digits!", "Invalid Entry", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Else
                    Dim connection As New MySqlConnection("server=localhost;user id=root;database=ordering_softeng")

                    Dim mstream As New MemoryStream()
                    PictureBox1.Image.Save(mstream, System.Drawing.Imaging.ImageFormat.Jpeg)
                    Dim images() As Byte = mstream.GetBuffer()
                    mstream.Close()

                    Dim parameters(8) As MySqlParameter

                    parameters(0) = New MySqlParameter("NAME", MySqlDbType.VarChar)
                    parameters(0).Value = nameTextBox.Text

                    parameters(1) = New MySqlParameter("AGE", MySqlDbType.VarChar)
                    parameters(1).Value = agetxt.Text

                    parameters(2) = New MySqlParameter("EMAIL", MySqlDbType.VarChar)
                    parameters(2).Value = emailTextBox.Text

                    parameters(3) = New MySqlParameter("ADDR", MySqlDbType.VarChar)
                    parameters(3).Value = addresstxt.Text

                    parameters(4) = New MySqlParameter("CONTACT", MySqlDbType.VarChar)
                    parameters(4).Value = contactTextBox.Text

                    parameters(5) = New MySqlParameter("GEN", MySqlDbType.VarChar)
                    parameters(5).Value = genderComboBox.Text

                    parameters(6) = New MySqlParameter("PID", MySqlDbType.VarChar)
                    parameters(6).Value = positionComboBox.Text

                    parameters(7) = New MySqlParameter("STAT", MySqlDbType.VarChar)
                    parameters(7).Value = statcombo.Text

                    parameters(8) = New MySqlParameter("IMAGE", MySqlDbType.Blob)
                    parameters(8).Value = images

                    Dim cmd As New MySqlCommand()
                    cmd.Connection = connection
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.CommandText = "inserts_staff"
                    cmd.Parameters.AddRange(parameters)
                    connection.Open()
                    If cmd.ExecuteNonQuery() = 1 Then
                        MessageBox.Show("Data Successfully Inserted!", "Insert Successful", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        insertuser()
                        retrieves()
                        autogenerate()
                        clear()
                    Else
                        MessageBox.Show("Not inserted")
                    End If
                    connection.Close()
                End If
            End If
        End If
    End Sub

    Private Sub clearbtn_Click(sender As Object, e As EventArgs) Handles clearbtn.Click
        clear()
        autogenerate()
    End Sub
    Sub search()
        connect()
        Dim query As String = "select *from staff,position,login_user where f_name like '%" & searchtxt.Text & "%' AND staff.p_id = position.p_id AND login_user.staff_id = staff.staff_id and login_user.pincode   "
        Try
            Dim cmd = New MySqlCommand(query, conn)
            Dim dr = cmd.ExecuteReader
            ListView1.Items.Clear()
            While dr.Read
                With ListView1.Items.Add(dr("staff_id").ToString)
                    .SubItems.Add(dr("f_name").ToString)
                    .SubItems.Add(dr("age").ToString)
                    .SubItems.Add(dr("email").ToString)
                    .SubItems.Add(dr("Address").ToString)
                    .SubItems.Add(dr("contact").ToString)
                    .SubItems.Add(dr("gender").ToString)
                    .SubItems.Add(dr("position").ToString)
                    .SubItems.Add(dr("status").ToString)
                    .SubItems.Add(dr("pincode").ToString)
                End With
            End While
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub searchbtn_Click(sender As Object, e As EventArgs) Handles searchbtn.Click
        search()
    End Sub

    Private Sub genderComboBox_KeyPress(sender As Object, e As KeyPressEventArgs) Handles genderComboBox.KeyPress
        e.Handled = Char.IsDigit(e.KeyChar) Or Not Char.IsDigit(e.KeyChar)
    End Sub

    Private Sub positionComboBox_KeyPress(sender As Object, e As KeyPressEventArgs) Handles positionComboBox.KeyPress
        e.Handled = Char.IsDigit(e.KeyChar) Or Not Char.IsDigit(e.KeyChar)
    End Sub

    Private Sub statcombo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles statcombo.KeyPress
        e.Handled = Char.IsDigit(e.KeyChar) Or Not Char.IsDigit(e.KeyChar)
    End Sub

    Private Sub idTextBox_KeyPress(sender As Object, e As KeyPressEventArgs) Handles idTextBox.KeyPress
        e.Handled = Char.IsDigit(e.KeyChar) Or Not Char.IsDigit(e.KeyChar)
    End Sub

    Private Sub contactTextBox_KeyPress(sender As Object, e As KeyPressEventArgs) Handles contactTextBox.KeyPress
        e.Handled = e.KeyChar <> ChrW(Keys.Back) And Not Char.IsDigit(e.KeyChar)
    End Sub

    Private Sub agetxt_KeyPress(sender As Object, e As KeyPressEventArgs) Handles agetxt.KeyPress
        e.Handled = e.KeyChar <> ChrW(Keys.Back) And Not Char.IsDigit(e.KeyChar)
    End Sub

    Private Sub nameTextBox_KeyPress(sender As Object, e As KeyPressEventArgs) Handles nameTextBox.KeyPress
        e.Handled = e.KeyChar <> ChrW(Keys.Back) And Not Char.IsSeparator(e.KeyChar) And Not Char.IsLetter(e.KeyChar)
    End Sub

    Private Sub pincode_KeyPress(sender As Object, e As KeyPressEventArgs) Handles pincode.KeyPress
        e.Handled = e.KeyChar <> ChrW(Keys.Back) And Not Char.IsDigit(e.KeyChar)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim openfile As New OpenFileDialog
        openfile.Filter = "png files (*. png )|*. png|jpg files(*. jpg)|*. jpg|All files (*_*)|*.*"
        If openfile.ShowDialog = DialogResult.OK Then
            imageLocation = openfile.FileName.ToString
            PictureBox1.ImageLocation = imageLocation
        End If
    End Sub

    Private Sub contactTextBox_TextChanged(sender As Object, e As EventArgs) Handles contactTextBox.TextChanged

    End Sub

End Class