﻿Imports MySql.Data.MySqlClient
Imports System.IO
Public Class loghistory

    Private Sub closeBtn_Click(sender As Object, e As EventArgs) Handles closeBtn.Click
        Me.Close()
    End Sub

    Private Sub loghistory_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        retrieves()
    End Sub
    Sub retrieves()
        connect()
        Dim dr As MySqlDataReader
        ListView1.Items.Clear()
        Try
            Dim query As String = "SELECT * FROM login_user,log_history,staff where login_user.staff_id = staff.staff_id and log_history.login_id = login_user.login_id  "
            Dim com As New MySqlCommand(query, conn)
            dr = com.ExecuteReader
            While dr.Read
                With ListView1.Items.Add(dr("loghistory_id").ToString)
                    .SubItems.Add(dr("f_name").ToString)
                    .SubItems.Add(dr("date").ToString)
                    .SubItems.Add(dr("TimeIN").ToString)
                    .SubItems.Add(dr("TimeOut").ToString)
                End With
            End While
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub ListView1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListView1.SelectedIndexChanged
        Dim index = ListView1.FocusedItem.Index
        Label9.Text = ListView1.Items(index).Text
        showinfo(Label9.Text)
    End Sub
    Sub showinfo(ByVal id As String)
        connect()
        Try
            Dim query As String = "SELECT * FROM login_user,log_history,staff where login_user.staff_id = staff.staff_id and log_history.login_id = login_user.login_id and log_history.loghistory_id = @id"
            Dim comm = New MySqlCommand(query, conn)
            comm.Parameters.AddWithValue("@id", id)
            Dim dr = comm.ExecuteReader
            While dr.Read
                Label9.Text = dr("loghistory_id").ToString
                Label5.Text = dr("f_name").ToString
                Label6.Text = dr("date").ToString
                Label7.Text = dr("TimeIN").ToString
                Label8.Text = dr("TimeOut").ToString

                Dim images() As Byte = dr("image")
                If images.Equals(Nothing) Then
                    PictureBox1.Image = Nothing
                Else
                    Dim ms As New MemoryStream(images)
                    PictureBox1.Image = Image.FromStream(ms)
                End If
            End While
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        conn.Close()
    End Sub

    Private Sub searchbtn_Click(sender As Object, e As EventArgs) Handles searchbtn.Click
        search()
    End Sub
    Sub search()
        connect()
        Dim query As String = "select * FROM login_user,log_history,staff where f_name like '%" & searchtxt.Text & "%' AND login_user.staff_id = staff.staff_id and log_history.login_id = login_user.login_id "
        Try
            Dim cmd = New MySqlCommand(query, conn)
            Dim dr = cmd.ExecuteReader
            ListView1.Items.Clear()
            While dr.Read
                With ListView1.Items.Add(dr("loghistory_id").ToString)
                    .SubItems.Add(dr("f_name").ToString)
                    .SubItems.Add(dr("date").ToString)
                    .SubItems.Add(dr("TimeIN").ToString)
                    .SubItems.Add(dr("TimeOut").ToString)
                End With
            End While
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
End Class