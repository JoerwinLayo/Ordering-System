﻿Imports MySql.Data.MySqlClient
Public Class staff_history
    Sub retrieves()
        connect()
        Dim dr As MySqlDataReader
        ListView1.Items.Clear()
        Try
            Dim query As String = "Select * from staff_history,position where staff_history.p_id = position.p_id "
            Dim com As New MySqlCommand(query, conn)
            dr = com.ExecuteReader
            While dr.Read
                With ListView1.Items.Add(dr("id").ToString)
                    .SubItems.Add(dr("name").ToString)
                    .SubItems.Add(dr("age").ToString)
                    .SubItems.Add(dr("email").ToString)
                    .SubItems.Add(dr("Address").ToString)
                    .SubItems.Add(dr("contact").ToString)
                    .SubItems.Add(dr("gender").ToString)
                    .SubItems.Add(dr("position").ToString)
                    .SubItems.Add(dr("status").ToString)
                End With
            End While
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub register_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        retrieves()
    End Sub
    Private Sub closeBtn_Click_1(sender As Object, e As EventArgs) Handles closeBtn.Click
        retrieves()
        Me.Hide()
        searchtxt.Text = ""
    End Sub
    Private Sub searchbtn_Click(sender As Object, e As EventArgs) Handles searchbtn.Click
        search()
    End Sub
    Sub search()
        connect()
        Dim query As String = "select *from staff_history, position where name like '%" & searchtxt.Text & "%' AND staff_history.p_id = position.p_id "
        Try
            Dim cmd = New MySqlCommand(query, conn)
            Dim dr = cmd.ExecuteReader
            ListView1.Items.Clear()
            While dr.Read
                With ListView1.Items.Add(dr("id").ToString)
                    .SubItems.Add(dr("name").ToString)
                    .SubItems.Add(dr("age").ToString)
                    .SubItems.Add(dr("email").ToString)
                    .SubItems.Add(dr("Address").ToString)
                    .SubItems.Add(dr("contact").ToString)
                    .SubItems.Add(dr("gender").ToString)
                    .SubItems.Add(dr("position").ToString)
                    .SubItems.Add(dr("status").ToString)
                End With
            End While
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub ListView1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListView1.SelectedIndexChanged

    End Sub
End Class