﻿Imports MySql.Data.MySqlClient
Public Class sales
    Dim monthNumber As String

    Sub MonthInNumber()
        Select Case comboBoxMonth.Text
            Case "January"
                monthNumber = "01"
            Case "February"
                monthNumber = "02"
            Case "March"
                monthNumber = "03"
            Case "April"
                monthNumber = "04"
            Case "May"
                monthNumber = "05"
            Case "June"
                monthNumber = "06"
            Case "July"
                monthNumber = "07"
            Case "August"
                monthNumber = "08"
            Case "September"
                monthNumber = "09"
            Case "October"
                monthNumber = "10"
            Case "November"
                monthNumber = "11"
            Case "December"
                monthNumber = "12"
            Case Else
                monthNumber = "00"
        End Select
    End Sub

    Private Sub dailyRadioButton_CheckedChanged(sender As Object, e As EventArgs) Handles dailyRadioButton.CheckedChanged
        If dailyRadioButton.Checked Then
            DateTimePicker1.Enabled = True
            comboBoxMonth.Enabled = False
            comboBoxYear.Enabled = False
        End If
    End Sub

    Private Sub monthRadioButton_CheckedChanged(sender As Object, e As EventArgs) Handles monthRadioButton.CheckedChanged
        If monthRadioButton.Checked Then
            DateTimePicker1.Enabled = False
            comboBoxMonth.Enabled = True
            comboBoxYear.Enabled = True
        End If
    End Sub

    Private Sub yearRadioButton_CheckedChanged(sender As Object, e As EventArgs) Handles yearRadioButton.CheckedChanged
        If yearRadioButton.Checked Then
            DateTimePicker1.Enabled = False
            comboBoxMonth.Enabled = False
            comboBoxYear.Enabled = True
        End If
    End Sub

    Private Sub loadBtn_Click(sender As Object, e As EventArgs) Handles loadBtn.Click
        If dailyRadioButton.Checked = False And monthRadioButton.Checked = False And yearRadioButton.Checked = False Then
            MessageBox.Show("Please select one of the radio buttons!", "Sales", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        ElseIf monthRadioButton.Checked = True And comboBoxMonth.Text = "" And comboBoxYear.Text = "" Then
            MessageBox.Show("Please select the Month and Year!", "Sales", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        ElseIf yearRadioButton.Checked = True And comboBoxYear.Text = "" Then
            MessageBox.Show("Please select the year!", "Sales", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else

            
            salesform.Show()
            loadSalesReport(DateTimePicker1.Text, comboBoxMonth.Text, comboBoxYear.Text)
            Me.Close()
        End If
    End Sub
    Sub loadSalesReport(ByVal day As String, ByVal month As String, ByVal year As String)
        salesform.ListView1.Items.Clear()
        MonthInNumber()
        Dim query As String
        Try
            If dailyRadioButton.Checked = True Then
                query = "SELECT invoiceID, total, cash, date, time, foodname, f_name FROM transaction " +
                       "JOIN foods ON transaction.food_id = foods.food_id " +
                       "JOIN login_user ON transaction.login_id = login_user.staff_id " +
                       "JOIN staff ON login_user.staff_id = staff.staff_id " +
                       "WHERE date = @day"

            ElseIf monthRadioButton.Checked = True Then
                query = "SELECT invoiceID, total, cash, date, time, foodname, f_name FROM transaction " +
                        "JOIN foods ON transaction.food_id = foods.food_id " +
                        "JOIN login_user ON transaction.login_id = login_user.staff_id " +
                        "JOIN staff ON login_user.staff_id = staff.staff_id " +
                        "WHERE date LIKE @month '%' and date LIKE '%' @year"
            Else
                query = "SELECT invoiceID, total, cash, date, time, foodname, f_name FROM transaction " +
                        "JOIN foods ON transaction.food_id = foods.food_id " +
                        "JOIN login_user ON transaction.login_id = login_user.staff_id " +
                        "JOIN staff ON login_user.staff_id = staff.staff_id " +
                        "WHERE date LIKE '%' @year"
            End If

            connect()
            Dim comm = New MySqlCommand(query, conn)
            comm.Parameters.AddWithValue("@day", day)
            comm.Parameters.AddWithValue("@month", monthNumber)
            comm.Parameters.AddWithValue("@year", year)
            Dim reader = comm.ExecuteReader

            While reader.Read
                With salesform.ListView1.Items.Add(reader("invoiceid").ToString)
                    .SubItems.Add(reader("total").ToString)
                    .SubItems.Add(reader("cash").ToString)
                    .SubItems.Add(reader("date").ToString)
                    .SubItems.Add(reader("time").ToString)
                    .SubItems.Add(reader("foodname").ToString)
                    .SubItems.Add(reader("f_name").ToString)
                End With
            End While

            If dailyRadioButton.Checked = True Then
                salesform.titleLabel.Text = "Sales for " + day
            ElseIf monthRadioButton.Checked = True Then
                salesform.titleLabel.Text = "Sales for the Month of " + month + " " + year
            Else
                salesform.titleLabel.Text = "Sales for the Year " + year
            End If


            sumUpAllStockSold()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        conn.Close()
    End Sub

    Sub sumUpAllStockSold()
        Try
            Dim TotalSum As Double = 0
            Dim i As ListViewItem
            For Each i In salesform.ListView1.Items
                TotalSum += Convert.ToDouble(i.SubItems.Item(1).Text)
            Next
            salesform.salesLabel.Text = TotalSum.ToString()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Me.Close()
        salesform.ToolStripLabel2.Enabled = False
    End Sub

    Private Sub DateTimePicker1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles DateTimePicker1.KeyPress
        e.Handled = Char.IsDigit(e.KeyChar) Or Not Char.IsDigit(e.KeyChar)
    End Sub

    Private Sub comboBoxMonth_KeyPress(sender As Object, e As KeyPressEventArgs) Handles comboBoxMonth.KeyPress
        e.Handled = Char.IsDigit(e.KeyChar) Or Not Char.IsDigit(e.KeyChar)
    End Sub

    Private Sub comboBoxYear_KeyPress(sender As Object, e As KeyPressEventArgs) Handles comboBoxYear.KeyPress
        e.Handled = Char.IsDigit(e.KeyChar) Or Not Char.IsDigit(e.KeyChar)
    End Sub

    Private Sub comboBoxMonth_SelectedIndexChanged(sender As Object, e As EventArgs) Handles comboBoxMonth.SelectedIndexChanged

    End Sub

    Private Sub DateTimePicker1_ValueChanged(sender As Object, e As EventArgs) Handles DateTimePicker1.ValueChanged

    End Sub
End Class