﻿Imports MySql.Data.MySqlClient
Imports System.IO
Public Class foodlist
    Dim imageLocation As String = ""
    Private Sub addBtn_Click(sender As Object, e As EventArgs) Handles addBtn.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or ComboBox1.Text = "" Then
            MessageBox.Show("Please Fill up the blank to insert!", "Textfields Empty", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            Dim connection As New MySqlConnection("server=localhost;user id=root;database=ordering_softeng")
            Dim mstream As New MemoryStream()
            PictureBox1.Image.Save(mstream, System.Drawing.Imaging.ImageFormat.Jpeg)
            Dim images() As Byte = mstream.GetBuffer()
            mstream.Close()
            Dim parameters(4) As MySqlParameter
            parameters(0) = New MySqlParameter("NAME", MySqlDbType.VarChar)
            parameters(0).Value = TextBox1.Text
            parameters(1) = New MySqlParameter("PR", MySqlDbType.Decimal)
            parameters(1).Value = TextBox2.Text
            parameters(2) = New MySqlParameter("QT", MySqlDbType.Decimal)
            parameters(2).Value = TextBox3.Text
            parameters(3) = New MySqlParameter("IMAGE", MySqlDbType.Blob)
            parameters(3).Value = images
            parameters(4) = New MySqlParameter("CAT", MySqlDbType.VarChar)
            parameters(4).Value = ComboBox1.Text
            Dim cmd As New MySqlCommand()
            cmd.Connection = connection
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "insert_foods"
            cmd.Parameters.AddRange(parameters)
            connection.Open()
            If cmd.ExecuteNonQuery() = 1 Then
                MessageBox.Show("Data Successfully Inserted!", "Insert Successful", MessageBoxButtons.OK, MessageBoxIcon.Information)
                retrieves()
                autogenerate()
                clear()
            Else
                MessageBox.Show("Not inserted")
            End If
            connection.Close()
        End If
    End Sub
    Sub clear()
        searchtxt.Text = ""
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        ComboBox1.Text = ""
        PictureBox1.Image = Nothing
    End Sub
    Sub autogenerate()
        connect()
        Try
            Dim sql As String = "SELECT * from view_food_generate"
            Dim cm As New MySqlCommand(sql, conn)
            Dim numbers As Integer

            If IsDBNull(cm.ExecuteScalar) Then
                numbers = 1
                idTextBox.Text = numbers
            Else
                numbers = cm.ExecuteScalar + 1
                idTextBox.Text = numbers
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        conn.Close()
    End Sub
    Private Sub foodlist_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        retrieves()
        autogenerate()
    End Sub
    Sub retrieves()
        connect()
        Dim dr As MySqlDataReader
        ListView1.Items.Clear()
        Try
            Dim query As String = "SELECT * FROM viewfoods"
            Dim com As New MySqlCommand(query, conn)
            dr = com.ExecuteReader
            While dr.Read
                With ListView1.Items.Add(dr("food_id").ToString)
                    .SubItems.Add(dr("foodname").ToString)
                    .SubItems.Add(dr("price").ToString)
                    .SubItems.Add(dr("quantity").ToString)
                    .SubItems.Add(dr("category").ToString)
                End With
            End While
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
  
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim openfile As New OpenFileDialog
        openfile.Filter = "png files (*. png )|*. png|jpg files(*. jpg)|*. jpg|All files (*_*)|*.*"
        If openfile.ShowDialog = DialogResult.OK Then
            imageLocation = openfile.FileName.ToString
            PictureBox1.ImageLocation = imageLocation
        End If
    End Sub
    Private Sub ListView1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListView1.SelectedIndexChanged
        Dim index = ListView1.FocusedItem.Index
        idTextBox.Text = ListView1.Items(index).Text
        showinfo(idTextBox.Text)
    End Sub
    Sub showinfo(ByVal id As String)
        connect()
        Try
            Dim query As String = "SELECT * FROM foods where food_id = @id"
            Dim comm = New MySqlCommand(query, conn)
            comm.Parameters.AddWithValue("@id", id)
            Dim dr = comm.ExecuteReader
            While dr.Read
                idTextBox.Text = dr("food_id").ToString
                TextBox1.Text = dr("foodname").ToString
                TextBox2.Text = dr("price").ToString
                TextBox3.Text = dr("quantity").ToString
                ComboBox1.Text = dr("category").ToString

                Dim images() As Byte = dr("image")
                If images.Equals(Nothing) Then
                    PictureBox1.Image = Nothing
                Else
                    Dim ms As New MemoryStream(images)
                    PictureBox1.Image = Image.FromStream(ms)
                End If
            End While
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        conn.Close()
    End Sub

    
    Private Sub updateBtn_Click(sender As Object, e As EventArgs) Handles updateBtn.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or ComboBox1.Text = "" Then
            MessageBox.Show("Please Choose to update!", "Textfields Empty", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or ComboBox1.Text = "" Then
                MessageBox.Show("Fill up all to update!", "Textfields Empty", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Else

                Dim connection As New MySqlConnection("server=localhost;user id=root;database=ordering_softeng")
                Dim mstream As New MemoryStream()
                PictureBox1.Image.Save(mstream, System.Drawing.Imaging.ImageFormat.Jpeg)
                Dim images() As Byte = mstream.GetBuffer()
                mstream.Close()
                Dim parameters(5) As MySqlParameter
                parameters(0) = New MySqlParameter("ID", MySqlDbType.VarChar)
                parameters(0).Value = idTextBox.Text
                parameters(1) = New MySqlParameter("NAME", MySqlDbType.VarChar)
                parameters(1).Value = TextBox1.Text
                parameters(2) = New MySqlParameter("PR", MySqlDbType.Decimal)
                parameters(2).Value = TextBox2.Text
                parameters(3) = New MySqlParameter("QT", MySqlDbType.Decimal)
                parameters(3).Value = TextBox3.Text
                parameters(4) = New MySqlParameter("IMAGE", MySqlDbType.Blob)
                parameters(4).Value = images
                parameters(5) = New MySqlParameter("CAT", MySqlDbType.VarChar)
                parameters(5).Value = ComboBox1.Text
                Dim cmd As New MySqlCommand()
                cmd.Connection = connection
                cmd.CommandType = CommandType.StoredProcedure
                cmd.CommandText = "update_foods"
                cmd.Parameters.AddRange(parameters)
                connection.Open()
                cmd.ExecuteNonQuery()
                MessageBox.Show("Data Successfully Updated!", "Update Successful", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                retrieves()
                autogenerate()
                clear()
                connection.Close()
            End If
        End If
    End Sub

    Private Sub searchbtn_Click(sender As Object, e As EventArgs) Handles searchbtn.Click
        search()
    End Sub
    Sub search()
        connect()
        Dim query As String = "select *from foods where foodname like '%" & searchtxt.Text & "%' or category  like '%" & searchtxt.Text & "%'"
        Try
            Dim cmd = New MySqlCommand(query, conn)
            Dim dr = cmd.ExecuteReader
            ListView1.Items.Clear()
            While dr.Read
                With ListView1.Items.Add(dr("food_id").ToString)
                    .SubItems.Add(dr("foodname").ToString)
                    .SubItems.Add(dr("price").ToString)
                    .SubItems.Add(dr("quantity").ToString)
                    .SubItems.Add(dr("category").ToString)
                End With
            End While
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub ToolStripLabel1_Click(sender As Object, e As EventArgs) Handles ToolStripLabel1.Click
        clear()
        Me.Hide()
        autogenerate()
        retrieves()
    End Sub

    Private Sub closeBtn_Click(sender As Object, e As EventArgs) Handles closeBtn.Click
        clear()
        autogenerate()
    End Sub

    Private Sub TextBox2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox2.KeyPress
        e.Handled = e.KeyChar <> ChrW(Keys.Back) And Not Char.IsDigit(e.KeyChar)
    End Sub

    Private Sub TextBox3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox3.KeyPress
        e.Handled = e.KeyChar <> ChrW(Keys.Back) And Not Char.IsDigit(e.KeyChar)
    End Sub

    Private Sub ComboBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles ComboBox1.KeyPress
        e.Handled = Char.IsDigit(e.KeyChar) Or Not Char.IsDigit(e.KeyChar)
    End Sub

    Private Sub idTextBox_KeyPress(sender As Object, e As KeyPressEventArgs) Handles idTextBox.KeyPress
        e.Handled = Char.IsDigit(e.KeyChar) Or Not Char.IsDigit(e.KeyChar)
    End Sub

    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress
        e.Handled = e.KeyChar <> ChrW(Keys.Back) And Not Char.IsSeparator(e.KeyChar) And Not Char.IsLetter(e.KeyChar)
    End Sub

   
  
    Private Sub searchtxt_TextChanged(sender As Object, e As EventArgs) Handles searchtxt.TextChanged

    End Sub
End Class